import random

def main():
    # The main function
    introduction = intro()
    board = create_grid()
    pretty = printPretty(board)
    mode = choose_mode()
    symbol_1, symbol_2 = sym()
    full = isFull(board, symbol_1, symbol_2, mode)  # Pass mode to the game logic


def intro():
    # This function introduces the rules of the game Tic Tac Toe
    print("Hello! Welcome to Pam's Tic Tac Toe game!")
    print("\n")
    print("Rules: Player 1 and player 2 (or the computer), represented by X and O, take turns "
          "marking the spaces in a 3x3 grid. The player who succeeds in placing "
          "three of their marks in a horizontal, vertical, or diagonal row wins.")
    print("\n")
    input("Press enter to continue.")
    print("\n")


def create_grid():
    # This function creates a blank playboard
    print("Here is the playboard: ")
    board = [[" ", " ", " "],
             [" ", " ", " "],
             [" ", " ", " "]]
    return board


def choose_mode():
    # This function allows the user to choose game mode
    while True:
        mode = input("Do you want to play against the computer or another player? (Enter 'computer' or 'player'): ").strip().lower()
        if mode in ['computer', 'player']:
            return mode
        else:
            print("Invalid choice. Please enter 'computer' or 'player'.")


def sym():
    # This function decides the players' symbols
    symbol_1 = input("Player 1, do you want to be X or O? ").upper()
    while symbol_1 not in ["X", "O"]:
        symbol_1 = input("Invalid choice. Please choose X or O: ").upper()
    if symbol_1 == "X":
        symbol_2 = "O"
        print("Player 2 (or computer), you are O.")
    else:
        symbol_2 = "X"
        print("Player 2 (or computer), you are X.")
    input("Press enter to continue.")
    print("\n")
    return symbol_1, symbol_2


def startGamming(board, symbol_1, symbol_2, count, mode):
    # This function starts the game and handles player/computer moves

    # Decides the turn
    if count % 2 == 0:
        player = symbol_1
        print("Player " + player + ", it is your turn.")
        row, column = get_player_move(board)
    else:
        if mode == "player":
            player = symbol_2
            print("Player " + player + ", it is your turn.")
            row, column = get_player_move(board)
        else:
            print("Computer's turn.")
            player = symbol_2
            row, column = computer_move(board)

    # Place the symbol on the board
    board[row][column] = player
    return board


def get_player_move(board):
    # Get a valid move from the player
    while True:
        try:
            row = int(input("Pick a row (0 for upper, 1 for middle, 2 for bottom): "))
            column = int(input("Pick a column (0 for left, 1 for middle, 2 for right): "))

            if 0 <= row <= 2 and 0 <= column <= 2:
                if board[row][column] == " ":
                    return row, column
                else:
                    print("The square is already filled. Pick another one.")
            else:
                print("Invalid input. Row and column must be between 0 and 2.")
        except ValueError:
            print("Invalid input. Please enter numbers between 0 and 2.")


def computer_move(board):
    # Simple AI to choose a random empty cell
    empty_cells = [(r, c) for r in range(3) for c in range(3) if board[r][c] == " "]
    return random.choice(empty_cells)


def isFull(board, symbol_1, symbol_2, mode):
    count = 1
    winner = True

    # This function checks if the board is full
    while count < 10 and winner:
        gaming = startGamming(board, symbol_1, symbol_2, count, mode)
        pretty = printPretty(board)

        if count == 9:
            print("The board is full. Game over.")
            if winner:
                print("There is a tie.")

        # Check if there is a winner
        winner = isWinner(board, symbol_1, symbol_2, count)
        count += 1

    if not winner:
        print("Game over.")

    # This function gives a report
    report(count, winner, symbol_1, symbol_2)


def printPretty(board):
    # This function prints the board nicely
    rows = len(board)
    print("---+---+---")
    for r in range(rows):
        print(f" {board[r][0]} | {board[r][1]} | {board[r][2]} ")
        print("---+---+---")
    return board


def isWinner(board, symbol_1, symbol_2, count):
    # This function checks if any player has won
    winner = True

    # Check the rows, columns, and diagonals
    for i in range(3):
        if (board[i][0] == board[i][1] == board[i][2] == symbol_1 or
                board[0][i] == board[1][i] == board[2][i] == symbol_1):
            print("Player " + symbol_1 + ", you won!")
            return False
        if (board[i][0] == board[i][1] == board[i][2] == symbol_2 or
                board[0][i] == board[1][i] == board[2][i] == symbol_2):
            print("Player " + symbol_2 + ", you won!")
            return False

    # Check diagonals
    if (board[0][0] == board[1][1] == board[2][2] == symbol_1 or
            board[0][2] == board[1][1] == board[2][0] == symbol_1):
        print("Player " + symbol_1 + ", you won!")
        return False

    if (board[0][0] == board[1][1] == board[2][2] == symbol_2 or
            board[0][2] == board[1][1] == board[2][0] == symbol_2):
        print("Player " + symbol_2 + ", you won!")
        return False

    return winner


def report(count, winner, symbol_1, symbol_2):
    print("\n")
    input("Press enter to see the game summary.")
    if not winner:
        if count % 2 == 1:
            print("Winner: Player " + symbol_1 + ".")
        else:
            print("Winner: Player " + symbol_2 + ".")
    else:
        print("There is a tie.")


# Call Main
main()

